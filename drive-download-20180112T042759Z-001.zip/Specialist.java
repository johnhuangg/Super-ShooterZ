/**
 * [Specialist.java]
 * this is the shotgunner class
 * @author John Huang
 * @date January 8, 2017
 */

class Specialist extends Player{
  /**
  * Specialist
  * constructor for specialist class, takes in a bunch of variables for the class
  * @param String name, int x, int y, int health, Weapon weapon, int h, int w
  */ 
  Specialist(String name, int x, int y, int health,Weapon weapon, int h, int w){
    super ( name,  x, y, health, weapon, h, w);
  }
  public void fire(int x, int y, int mx, int my){
    Bullet bullet = new Bullet(x, y, mx, my, 300, 5, getName());
  }
}