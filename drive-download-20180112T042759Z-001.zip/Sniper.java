/**
 * [Sniper.java]
 * this is the sniper class
 * @author John Huang
 * @date January 8, 2017
 */

class Sniper extends Player{
  /**
  * sniper
  * constructor for sniper class, takes in a bunch of variables for the class
  * @param String name, int x, int y, int health, Weapon weapon, int h, int w
  */ 
  Sniper(String name, int x, int y, int health,Weapon weapon, int h, int w){
    super ( name,  x, y, health, weapon, h, w);
  }
  public void fire(int x, int y, int mx, int my){
    Bullet bullet = new Bullet(x, y, mx, my, 300, 50, getName());
  }
}