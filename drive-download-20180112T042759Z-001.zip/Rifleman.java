/**
 * [Rifleman.java]
 * this is the rifleman class
 * @author John Huang
 * @date January 8, 2017
 */

class Rifleman extends Player{
  /**
  * rifleman
  * constructor for rifleman class, takes in a bunch of variables for the class
  * @param String name, int x, int y, int health, Weapon weapon, int h, int w
  */ 
  Rifleman(String name, int x, int y, int health,Weapon weapon, int h, int w){
    super ( name,  x, y, health, weapon, h, w);
  }
  public void fire(int x, int y, int mx, int my){
    Bullet bullet = new Bullet(x, y, mx, my, 300, 1, getName());
  }
}