/**
* This template can be used as reference or a starting point
* for your final summative project
* @author Mangat
**/

//Graphics &GUI imports
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.imageio.ImageIO;
import java.awt.Toolkit;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;

//Keyboard imports
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

//Mouse imports
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

class BackgroundFrame extends JFrame {

	// class variable (non-static)
	private BufferedImage image;
	// int trueX = 0;
	// int trueY = 0;
	int bgX = 0;
	int bgY = 0;

	Platform[] platforms = new Platform[9]; // array to store all the platforms
	int[][] platformData = { { 0, 200, 250, 200 }, { 4870, 200, 250, 200 }, { 0, 3000, 250, 200 },
			{ 4870, 3000, 250, 200 }, // spawn platforms
			{ 500, 200, 250, 200 }, { 4300, 200, 250, 200 }, { 1560, 200, 2000, 200 }, { 3800, 200, 250, 200 },
			{ 1000, 200, 250, 200 } }; // upper platforms

	int[][] platformDataCopy = { { 0, 200, 250, 200 }, { 4870, 200, 250, 200 }, { 200, 3000, 250, 200 },
			{ 4870, 3000, 250, 200 }, // spawn platforms
			{ 500, 200, 250, 200 }, { 4300, 200, 250, 200 }, { 1560, 200, 2000, 200 }, { 3800, 200, 250, 200 },
			{ 1000, 200, 250, 200 } }; // upper platforms
	// copy array of the platform data to store original coordinates (platformData
	// changesupdates with movement)

	// Constructor - this runs first
	BackgroundFrame() {
		try { // loads background image
			image = ImageIO.read(new File("background2.jpg"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		makePlatforms();
	} // End of Constructor

	// the main gameloop - this is where the game state is updated
	public void update(int x, int y) {
		
		bgX = x;
		bgY = y;
		
		if (bgX > 0) {
			bgX = 0;
		}
		if (bgY > 0) {
			bgY = 0;
		}
		if (bgX < -3840) {
			bgX = -3840;
		}
		if (bgY < -2400) {
			bgY = -2400;
		}

		for (int i = 0; i < platforms.length; i++) { // prevents platforms from moving off the screen
			if (platformData[i][0] > platformDataCopy[i][0]) { // left boundary
				platformData[i][0] = platformDataCopy[i][0];
			}
			if (platformData[i][0] < (platformDataCopy[i][0] - 3840)) { // right boundary
				platformData[i][0] = platformDataCopy[i][0] - 3840;
			}
			if (platformData[i][1] > platformDataCopy[i][1]) { // upper boundary
				platformData[i][1] = platformDataCopy[i][1];
			}
			if (platformData[i][1] < (platformDataCopy[i][1] - 2400)) { // lower boundary
				platformData[i][1] = platformDataCopy[i][1] - 2400;
			}
		}

		for (int i = 0; i < platforms.length; i++) { // used to move platforms with the screen
			platformData[i][0] = x;
			platformData[i][1] = y;
		}
		
		try {
			Thread.sleep(1);
		} catch (Exception e) {
		}
	}

	public void makePlatforms() { // constructs platforms

		for (int i = 0; i < platforms.length; i++) {
			platforms[i] = new Platform(platformData[i][0], platformData[i][1], platformData[i][2], platformData[i][3]);
		}
	}

	public void draw(Graphics g) {
		g.drawImage(image, bgX, bgY, 5120, 3200, null);
		for (int i = 0; i < platforms.length; i++) {
			g.drawImage(platforms[i].getImage(), platformData[i][0], platformData[i][1], platformData[i][2],
					platformData[i][3], null);
		}
	}
}