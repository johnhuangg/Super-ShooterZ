import java.awt.Graphics;

/**
 * [Bullet.java]
 * This is the bullet class
 * @author Andrew Wu
 * Date: January 4, 2018
 */

class Bullet {
	private int damage;
	private int x, y; // players coords
	private int mX, mY; // mouse coords
	private int speed = 10;
	private double angle;
	private int range;
	private int travelled;
	double xVelocity;
	double yVelocity;
	private String owner;

	// constructor
	public Bullet(int x, int y, int mX, int mY, int range, int damage, String owner) {
		this.x = x;
		this.y = y;
		this.mX = mX;
		this.mY = mY;
		this.range = range;
		this.damage = damage;
		this.owner = owner;
	}// end of Bullet constructor
	
	/**
	 * getOwner
	 * method that returns owner of bullet
	 * @params nothing
	 * returns String
	 */
	public String getOwner() {
		return this.owner;
	}

	/**
	 * drawEnemyBullet
	 * method that draws other player's bullets
	 * @params Graphics
	 * returns nothing
	 */
	public void drawEnemyBullet(Graphics g) {
		g.drawOval(x, y, 15,15);
	}//end of drawEnemyBullet
	
	/**
	 * drawMyBullet
	 * method that draws a player's own bullets, the coords being from the 
	 * center of the screen
	 * @params Graphics
	 * returns nothing
	 */
	public void drawMyBullet(Graphics g) {
		g.drawOval((int)(640+xVelocity),(int)(y+yVelocity),15,15);
	}//end of drawMyBullet
	
	/**
	 * update 
	 * updates the position of the bullet
	 * @params nothing 
	 * returns nothing
	 */
	public boolean update() {
		if(travelled < range) {
			// find angle at which bullet is shot from
			angle = Math.atan2(mX - x, mY - y);
			// calculate velocity
			xVelocity = (speed) * Math.sin(angle);
			yVelocity = (speed) * Math.cos(angle);

			// temporary storage of past coords
			int tempX = x;
			int tempY = y;

			// update new coords
			x += xVelocity;
			y += yVelocity;

			// calculate distance traveled
			travelled += (int) Math.sqrt(Math.pow(tempX-x,2) + Math.pow(tempY-y,2));
			return true;
		}
		return false;
	}//end of update
}// end of Bullet class