/**
 * [Scout.java]
 * this is the scout class
 * @author John Huang
 * @date January 8, 2017
 */

class Scout extends Player{
  /**
  * scout
  * constructor for scout class, takes in a bunch of variables for the class
  * @param String name, int x, int y, int health, Weapon weapon, int h, int w
  */ 
  Scout(String name, int x, int y, int health,Weapon weapon, int h, int w){
    super ( name,  x, y, health, weapon, h, w);
  }
  public void fire(int x, int y, int mx, int my){
    Bullet bullet = new Bullet(x, y, mx, my, 300,5, getName());
  }
}