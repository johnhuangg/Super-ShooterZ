/**
 * [Player.java]
 * this is the player class
 * @author John Huang
 * @date December 18,2017
 */
import java.awt.Rectangle;
class Player {
 //class variables
 private int x;
 private int y;
 private int h;
 private int w;
 private int maxHealth;
 private int currentHealth;
 private Weapon weapon;
 private String name;
 private Rectangle collisionBox;
 private int xdirection,ydirection;
 private int gravity=1;
 private int terminalVelocity=2;
 private int vertSpeed; 
 /**
  * Player
  * constructor for player class, takes in a bunch of variables for the class
  * @param String name, int x, int y, int health,Weapon weapon, int h, int w
  */ 
 Player(String name, int x, int y, int health,Weapon weapon, int h, int w) {
  this.name = name;
  this.x = x;
  this.y = y;
  this.maxHealth = currentHealth;
  this.collisionBox=new Rectangle((int)x, (int)y, w, h);
  this.weapon = weapon;
 }
  
  /**
   * setX
   * this sets the x coordinate of the player
   * @param int x which is the x coordinate
   */ 
  public void setX(int x){
    this.x=x;
  }
  /**
   * setX
   * this sets the x coordinate of the player
   * @param int x which is the x coordinate
   */ 
  public void setY(int y){
    this.y=y;
  }
  /**
   * getX
   * this gets the x coordinate of the player
   * @return int x which is the x coordinate
   */ 
  public int getX(){
    return this.x;
  }
  /**
   * getY
   * this gets the y coordinate of the player
   * @return int y which is the y coordinate
   */ 
  public int getY(){
    return this.y;
  }
  /**
   * getMaxHealth
   * this gets the maximum health of the player
   * @return int maxHealth which is the maxHealth
   */ 
  public int getMaxHealth(){
    return this.maxHealth;
  }
  /**
   * getCurrentHealth
   * this gets the current health of the player
   * @return int currentHealth which is the currentHealth
   */ 
  public int getCurrentHealth(){
    return this.currentHealth;
  }
  /**
   * setCurrentHealth
   * this sets the current health of the player
   * @param int currentHealth which is the currentHealth
   */ 
  public void setCurrentHealth(int currentHealth){
    this.currentHealth=currentHealth;
  }
  /**
   * setWeapon
   * this sets weapon of the player
   * @param Weapon weapon which is the weapon
   */ 
  public void setWeapon(Weapon weapon){
    this.weapon=weapon;
  }
  /**
   * getWeapon
   * this gets the weapon of the player
   * @return Weapon weapon which is the weapon
   */ 
  public Weapon weapon(){
    return this.weapon;
  }
  
  /**
   * getName
   * this gets the name of the player
   * @return String name 
   */
  public String getName() {
   return this.name;
  }
  /**
   * fire
   * this is empty method for overriding
   */
  public void fire() {
  }
  /**
   * fall
   * this is method to make the player fall
   */
   public void fall(){
     this.vertSpeed=this.vertSpeed-gravity;
     if (this.vertSpeed > terminalVelocity)
     {
       this.vertSpeed = terminalVelocity;
     }
     this.y = this.y - this.vertSpeed;
     try{
     Thread.sleep(20);
     }catch (Exception e){
       
     }
   }
}