/**
 * [Player.java]
 * this is the player class
 * @author John Huang
 * @date December 18,2017
 */
import java.awt.Rectangle;
abstract class Player {
 //class variables
 private int x;
 private int y;
 private int h;
 private int w;
 private int maxHealth;
 private int currentHealth;
 private int lives;
 private Weapon weapon;
 private String name;
 private Rectangle boundingBox;
 private int xdirection,ydirection;
 private int gravity=1;
 private int terminalVelocity=2;
 private int vertSpeed; 
 private boolean falling;
 
 /**
  * Player
  * constructor for player class, takes in a bunch of variables for the class
  * @param String name, int x, int y, int health,Weapon weapon, int h, int w
  */ 
 Player(String name, int x, int y, int health,Weapon weapon, int h, int w) {
  this.name = name;
  this.x = x;
  this.y = y;
  this.currentHealth = health;
  this.maxHealth = this.currentHealth;
  this.boundingBox=new Rectangle((int)x, (int)y, w, h);
  this.weapon = weapon;
  this.lives = 3;
  this.falling = true;
  this.vertSpeed = 0;
 }
  
 /**
  * setLives
  * this set players lives
  */
 public void setLives(int lives) {
	 this.lives = lives;
 }//end of setLives
 
  /**
   * setX
   * this sets the x coordinate of the player
   * @param int x which is the x coordinate
   */ 
  public void setX(int x){
	this.boundingBox.x = x;
    this.x=x;
  }
  /**
   * setY
   * this sets the y coordinate of the player
   * @param int y which is the y coordinate
   */ 
  public void setY(int y){
	this.boundingBox.y = y;
    this.y=y;
  }

  /**
   * getLives
   * this returns players lives
   */
  public int getLives() {
	  return this.lives;
  }//end of getLives
  
  /**
   * getX
   * this gets the x coordinate of the player
   * @return int x which is the x coordinate
   */ 
  public int getX(){
    return this.x;
  }
  /**
   * getY
   * this gets the y coordinate of the player
   * @return int y which is the y coordinate
   */ 
  public int getY(){
    return this.y;
  }
  /**
   * getMaxHealth
   * this gets the maximum health of the player
   * @return int maxHealth which is the maxHealth
   */ 
  public int getMaxHealth(){
    return this.maxHealth;
  }
  /**
   * getCurrentHealth
   * this gets the current health of the player
   * @return int currentHealth which is the currentHealth
   */ 
  public int getCurrentHealth(){
    return this.currentHealth;
  }
  /**
   * setCurrentHealth
   * this sets the current health of the player
   * @param int currentHealth which is the currentHealth
   */ 
  public void setCurrentHealth(int currentHealth){
    this.currentHealth=currentHealth;
  }
  /**
   * setWeapon
   * this sets weapon of the player
   * @param Weapon weapon which is the weapon
   */ 
  public void setWeapon(Weapon weapon){
    this.weapon=weapon;
  }
  /**
   * getWeapon
   * this gets the weapon of the player
   * @return Weapon weapon which is the weapon
   */ 
  public Weapon weapon(){
    return this.weapon;
  }
  
  /**
   * getName
   * this gets the name of the player
   * @return String name 
   */
  public String getName() {
   return this.name;
  }
  
  /**
   * getVertSpeed
   */
  public int getVertSpeed() {
	  return this.vertSpeed;
  }
  /**
   * fire
   * this is empty method for overriding
   */
  public void fire(int x, int y, Client client) {
	  
  }
  
  /**
   * checkShot
   * checks if Player has been hit with a bullet object
   * @params Rectangle
   * returns boolean
   */
  public boolean checkShot(Bullet bullet) {
	  if(bullet.getBoundingBox().intersects(boundingBox)) {
		  return true;
		}
		return false;
	}// end of check

	/**
	 * fall this is method to make the player fall
	 */
	public void fall() {
		this.vertSpeed = this.vertSpeed + gravity;
		if (this.vertSpeed > terminalVelocity) {
			this.vertSpeed = terminalVelocity;
		}
		//if (this.falling) {
			this.y = this.y + this.vertSpeed;
		//}
		
		/*try {
			Thread.sleep(20);
		} catch (Exception e) {

		}*/
	}
   
	/**
	 * collisionDetect this is the collision method
	 */
	public boolean collisionDetect(Platform[] platforms) {
		for (int i = 0; i < platforms.length; i++) {
			if (this.boundingBox.intersects(platforms[i].getRect())) {
				setY((int) platforms[i].getRect().getY());
				this.falling = false;
				this.vertSpeed = 0;
			}else {
				this.falling=true;
			}
		}
		//System.out.println("falling: " + falling + " vertSpeed: " + vertSpeed);
		return this.falling;
	}
}