/**
 * [HealthBar.java]
 * this is the healthbar class
 * @author John Huang
 * @date January 11, 2018
 */

import java.awt.Graphics;
import java.awt.Color;
import java.awt.Font;

class HealthBar{
 private double maxHealth=100.0;
 private int currentHealth=100;
 private int outerWidth=200;
 private int outerHeight=50;
 private int innerWidthAdjust=180;
 private int innerWidth=180;
 private int innerHeight=40;
 private int outerX=540;
 private int outerY=700;
 private int innerX=550;
 private int innerY=705;
 /**
  * HealthBar
  * constructor for HealthBar
  */ 
 HealthBar(){
   
 }
 /**
  * draw
  * method for drawing the rectangles for healthbar
  **/ 
 public void draw(Graphics g) {
   g.setColor(Color.GRAY);
   g.fillRect(outerX,outerY,outerWidth,outerHeight); 
   g.setColor(Color.RED); 
   g.fillRect(innerX, innerY, innerWidthAdjust,innerHeight); 
   g.setColor(Color.WHITE);
   g.setFont(new Font ("Arial",Font.BOLD,24));
   g.drawString(currentHealth+"/100",605,735);

 }
 /**
  * setCurrentHealth
  * method for drawing the rectangles for healthbar
  **/ 
 public void setCurrentHealth(int health){
   this.currentHealth=health;
   innerWidthAdjust=(int)((currentHealth/maxHealth)*innerWidth);   
 }
}