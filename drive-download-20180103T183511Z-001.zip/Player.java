/**
 * [Player.java]
 * this is the player class
 * @author John Huang
 * @date December 18,2017
 */
class Player {
	private int x;
	private int y;
	private int maxHealth;
	private int currentHealth;
	private Weapon weapon;
	private String name;

	Player(int x, int y) {
		this.x = x;
		this.y = y;
	}

	Player(String name, int x, int y, int health) {
		this.name = name;
		this.x = x;
		this.y = y;
		this.maxHealth = currentHealth;
	}

	Player(String name, int x, int y, int health, Weapon weapon) {
		this.name = name;
		this.x = x;
		this.y = y;
		this.maxHealth = currentHealth;
		this.weapon = weapon;
  }
  
  /**
   * setX
   * this sets the x coordinate of the player
   * @param int x which is the x coordinate
   */ 
  public void setX(int x){
    this.x=x;
  }
  /**
   * setX
   * this sets the x coordinate of the player
   * @param int x which is the x coordinate
   */ 
  public void setY(int y){
    this.y=y;
  }
  /**
   * getX
   * this gets the x coordinate of the player
   * @return int x which is the x coordinate
   */ 
  public int getX(){
    return this.x;
  }
  /**
   * getY
   * this gets the y coordinate of the player
   * @return int y which is the y coordinate
   */ 
  public int getY(){
    return this.y;
  }
  /**
   * getMaxHealth
   * this gets the maximum health of the player
   * @return int maxHealth which is the maxHealth
   */ 
  public int getMaxHealth(){
    return this.maxHealth;
  }
  /**
   * getCurrentHealth
   * this gets the current health of the player
   * @return int currentHealth which is the currentHealth
   */ 
  public int getCurrentHealth(){
    return this.currentHealth;
  }
  /**
   * setCurrentHealth
   * this sets the current health of the player
   * @param int currentHealth which is the currentHealth
   */ 
  public void setCurrentHealth(int currentHealth){
    this.currentHealth=currentHealth;
  }
  /**
   * setWeapon
   * this sets weapon of the player
   * @param Weapon weapon which is the weapon
   */ 
  public void setWeapon(Weapon weapon){
    this.weapon=weapon;
  }
  /**
   * getWeapon
   * this gets the weapon of the player
   * @return Weapon weapon which is the weapon
   */ 
  public Weapon weapon(){
    return this.weapon;
  }
  
  /**
   * getName
   * this gets the name of the player
   * @return String name 
   */
  public String getName() {
	  return this.name;
  }
}